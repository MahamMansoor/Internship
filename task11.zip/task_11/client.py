# client_interpreter.py

import json
from status_tracker import initialize_features

def parse_client_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    project = ''
    timeline = ''
    priority = ''
    features = []

    for line in lines:
        line = line.strip()
        if line.startswith("Project:"):
            project = line.split(":", 1)[1].strip()
        elif line.startswith("Timeline:"):
            timeline = line.split(":", 1)[1].strip()
        elif line.startswith("Priority:"):
            priority = line.split(":", 1)[1].strip()
        elif line.startswith("-"):
            features.append(line.lstrip("- ").strip())

    return {
        "project": project,
        "timeline": timeline,
        "priority": priority,
        "features": features
    }

def format_summary(data):
    summary = [
        "📘 Project Summary Report",
        "-------------------------",
        f"Project: {data['project']}",
        f"Timeline: {data['timeline']}",
        f"Priority: {data['priority']}",
        "Features to Implement:"
    ]
    for feature in data['features']:
        summary.append(f" - {feature}")
    return "\n".join(summary)

def write_summary_to_txt(summary, file_path="project_summary.txt"):
    with open(file_path, 'w') as file:
        file.write(summary)

def write_summary_to_json(data, file_path="project_summary.json"):
    summary_data = {
        "project": data['project'],
        "timeline": data['timeline'],
        "priority": data['priority'],
        "features": initialize_features(data['features'])
    }
    with open(file_path, 'w') as json_file:
        json.dump(summary_data, json_file, indent=4)

def main():
    input_file = "client_requirements.txt"
    parsed_data = parse_client_file(input_file)

    # Print summary to console
    summary = format_summary(parsed_data)
    print(summary)

    # Export to TXT and JSON
    write_summary_to_txt(summary)
    write_summary_to_json(parsed_data)

if __name__ == "__main__":
    main()
