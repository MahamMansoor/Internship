# status_tracker.py

def initialize_features(features_list):
    """
    Takes a list of features and returns a dictionary with each feature's status set to 'pending'.
    """
    return {feature: "pending" for feature in features_list}
