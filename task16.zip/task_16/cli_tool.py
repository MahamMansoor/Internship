# cli_tool.py
import argparse
import json
import os
from datetime import datetime

DATA_FILE = "todo_data.json"
LOG_FILE = "error_log.txt"

def log_error(message):
    with open(LOG_FILE, "a") as log:
        log.write(f"[{datetime.now()}] {message}\n")

def load_tasks():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            log_error("Failed to decode JSON.")
            return []
    return []

def save_tasks(tasks):
    try:
        with open(DATA_FILE, "w") as f:
            json.dump(tasks, f, indent=2)
    except Exception as e:
        log_error(f"Error saving tasks: {e}")

def add_task(task):
    tasks = load_tasks()
    tasks.append(task)
    save_tasks(tasks)
    print(f"✅ Task added: {task}")

def view_tasks():
    tasks = load_tasks()
    if not tasks:
        print("No tasks found.")
    else:
        print("📋 To-Do List:")
        for i, task in enumerate(tasks, 1):
            print(f"{i}. {task}")

def delete_task(index):
    try:
        tasks = load_tasks()
        task = tasks.pop(index - 1)
        save_tasks(tasks)
        print(f"❌ Deleted: {task}")
    except (IndexError, ValueError):
        log_error("Invalid task number to delete.")
        print("⚠️ Invalid task number.")

def main():
    parser = argparse.ArgumentParser(description="Simple To-Do List CLI Tool")
    parser.add_argument("action", choices=["add", "view", "delete"], help="Action to perform")
    parser.add_argument("--task", help="Task description")
    parser.add_argument("--index", type=int, help="Task number to delete")

    args = parser.parse_args()

    try:
        if args.action == "add":
            if args.task:
                add_task(args.task)
            else:
                print("⚠️ Please provide a task using --task")
        elif args.action == "view":
            view_tasks()
        elif args.action == "delete":
            if args.index:
                delete_task(args.index)
            else:
                print("⚠️ Provide --index to delete a task.")
    except Exception as e:
        log_error(f"Unhandled error: {e}")
        print("⚠️ An unexpected error occurred.")

if __name__ == "__main__":
    main()
