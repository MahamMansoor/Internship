# test_script.py
import unittest
import os
from cli_tool import add_task, load_tasks, delete_task, save_tasks

class TestTodoCLI(unittest.TestCase):
    def setUp(self):
        self.sample_tasks = ["Buy milk", "Read book"]
        save_tasks(self.sample_tasks)

    def tearDown(self):
        if os.path.exists("todo_data.json"):
            os.remove("todo_data.json")
        if os.path.exists("error_log.txt"):
            os.remove("error_log.txt")

    def test_add_task(self):
        add_task("Walk dog")
        tasks = load_tasks()
        self.assertIn("Walk dog", tasks)

    def test_delete_task_valid(self):
        delete_task(1)
        tasks = load_tasks()
        self.assertNotIn("Buy milk", tasks)

    def test_delete_task_invalid(self):
        delete_task(99)  # should trigger error handling

if __name__ == "__main__":
    unittest.main()
