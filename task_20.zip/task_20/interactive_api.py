import requests

def get_weather(city, api_key):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        main = data['main']
        weather = data['weather'][0]
        print(f"\n📍 City: {data['name']}")
        print(f"🌡️ Temperature: {main['temp']}°C")
        print(f"💧 Humidity: {main['humidity']}%")
        print(f"🌤️ Weather: {weather['description'].title()}")
    else:
        print("❌ City not found or API error.")

if __name__ == "__main__":
    print("🌍 Weather Forecast App")
    api_key = input("🔑 Enter your OpenWeatherMap API key: ")
    city = input("🏙️ Enter city name: ")
    get_weather(city, api_key)
