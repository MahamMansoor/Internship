# 🌍 Weather Forecast App — #ProSensiaInternship

This is a simple command-line app that uses the **OpenWeatherMap API** to fetch current weather information based on user input.

## 🚀 How It Works
- User enters their API key and a city name
- App fetches temperature, humidity, and weather condition
- Output is formatted and easy to read

## 🧪 Example Output
