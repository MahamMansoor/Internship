import requests
import json

def fetch_api_data(url):
    """Fetch data from the API and return JSON, or None on failure."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error fetching data: {e}")
        return None

def extract_prices(data, keyword=None):
    """
    Extract and return currency names and prices from the JSON data.
    Filters keys by keyword if provided.
    """
    prices = {}
    if "bpi" in data:
        for code, info in data["bpi"].items():
            if not keyword or keyword.lower() in code.lower() or keyword.lower() in info['description'].lower():
                prices[code] = f"{info['symbol']}{info['rate']}"
    return prices

def format_report(prices):
    """Return formatted string for report."""
    report_lines = ["📊 Bitcoin Price Report", "--------------------------"]
    for currency, price in prices.items():
        report_lines.append(f"{currency}: {price}")
    return "\n".join(report_lines)

def save_report(report, filename="btc_price_report.txt"):
    """Save the report to a text file."""
    with open(filename, 'w') as file:
        file.write(report)

def main():
    print("🌐 API Data Fetcher & Bitcoin Price Analyzer")
    default_url = "https://api.coindesk.com/v1/bpi/currentprice.json"
    url = input(f"Enter API URL (or press Enter for default):\n> ") or default_url

    keyword = input("Optional: Enter keyword to filter currencies (e.g., usd, euro):\n> ").strip()
    keyword = keyword if keyword else None

    data = fetch_api_data(url)
    if not data:
        return

    prices = extract_prices(data, keyword)
    if not prices:
        print("⚠️ No matching currency data found.")
        return

    report = format_report(prices)
    print("\n" + report)
    save_report(report)
    print("\n✅ Report saved to btc_price_report.txt")

if __name__ == "__main__":
    main()
