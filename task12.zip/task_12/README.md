# 📊 API Data Fetcher & Bitcoin Price Analyzer

## Description
A Python CLI tool that fetches real-time Bitcoin Price Index data using a public API and outputs it in a clean report format.

## Features
- Fetches JSON data using `requests`
- Parses and filters currencies
- Prints and saves a formatted report
- Supports custom API URL input
- Error handling for API issues

## Sample API Used
[https://api.coindesk.com/v1/bpi/currentprice.json](https://api.coindesk.com/v1/bpi/currentprice.json)

## How to Run
```bash
python api_fetcher.py
