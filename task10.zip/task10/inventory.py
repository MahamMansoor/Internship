import random

def generate_restock_quantity():
    return random.randint(5, 15)
