import tkinter as tk
from tkinter import messagebox
from main import InventoryManager, Product, PerishableProduct

manager = InventoryManager()

def add_product():
    name = entry_name.get()
    price = float(entry_price.get())
    qty = int(entry_qty.get())
    if var_is_perishable.get():
        expiry = int(entry_expiry.get())
        product = PerishableProduct(name, price, qty, expiry)
    else:
        product = Product(name, price, qty)

    manager.add_product(product)
    messagebox.showinfo("Success", "Product added!")
    entry_name.delete(0, tk.END)
    entry_price.delete(0, tk.END)
    entry_qty.delete(0, tk.END)
    entry_expiry.delete(0, tk.END)

def view_inventory():
    output.delete(0, tk.END)
    for item in manager.get_inventory():
        output.insert(tk.END, item)

def search_product():
    term = entry_search.get()
    output.delete(0, tk.END)
    results = manager.search_by_name(term)
    if results:
        for item in results:
            output.insert(tk.END, str(item))
    else:
        output.insert(tk.END, "No product found.")

def restock():
    manager.restock_all()
    messagebox.showinfo("Done", "All products restocked.")

def export_all():
    manager.export_summary_txt()
    manager.export_summary_csv()
    messagebox.showinfo("Exported", "Reports saved as .txt and .csv")

# GUI Setup
root = tk.Tk()
root.title("📦 Inventory Manager")

tk.Label(root, text="Name").grid(row=0, column=0)
tk.Label(root, text="Price").grid(row=1, column=0)
tk.Label(root, text="Quantity").grid(row=2, column=0)
tk.Label(root, text="Expiry Days").grid(row=3, column=0)

entry_name = tk.Entry(root)
entry_price = tk.Entry(root)
entry_qty = tk.Entry(root)
entry_expiry = tk.Entry(root)

entry_name.grid(row=0, column=1)
entry_price.grid(row=1, column=1)
entry_qty.grid(row=2, column=1)
entry_expiry.grid(row=3, column=1)

var_is_perishable = tk.BooleanVar()
chk_perishable = tk.Checkbutton(root, text="Is Perishable?", variable=var_is_perishable)
chk_perishable.grid(row=4, column=0, columnspan=2)

tk.Button(root, text="Add Product", command=add_product).grid(row=5, column=0, columnspan=2)
tk.Button(root, text="View Inventory", command=view_inventory).grid(row=6, column=0, columnspan=2)
tk.Button(root, text="Restock All", command=restock).grid(row=7, column=0, columnspan=2)

tk.Label(root, text="Search Name").grid(row=8, column=0)
entry_search = tk.Entry(root)
entry_search.grid(row=8, column=1)
tk.Button(root, text="Search", command=search_product).grid(row=9, column=0, columnspan=2)

output = tk.Listbox(root, width=60)
output.grid(row=10, column=0, columnspan=2)

tk.Button(root, text="Export Report", command=export_all).grid(row=11, column=0, columnspan=2)

root.mainloop()
