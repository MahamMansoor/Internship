import csv
from inventory import generate_restock_quantity

class Product:
    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price
        self.quantity = quantity

    def total_value(self):
        return self.price * self.quantity

    def __str__(self):
        return f"{self.name} - Price: ${self.price}, Qty: {self.quantity}, Total: ${self.total_value():.2f}"

class PerishableProduct(Product):
    def __init__(self, name, price, quantity, expiry_days):
        super().__init__(name, price, quantity)
        self.expiry_days = expiry_days

    def total_value(self):
        base = super().total_value()
        return base * 0.8 if self.expiry_days < 5 else base

    def __str__(self):
        note = " (20% Off)" if self.expiry_days < 5 else ""
        return f"{self.name} - Price: ${self.price}, Qty: {self.quantity}, Exp: {self.expiry_days}d{note}, Total: ${self.total_value():.2f}"

class InventoryManager:
    def __init__(self):
        self.products = []

    def add_product(self, product):
        self.products.append(product)

    def get_inventory(self):
        return [str(p) for p in self.products]

    def search_by_name(self, term):
        return list(filter(lambda p: term.lower() in p.name.lower(), self.products))

    def restock_all(self):
        for product in self.products:
            product.quantity += generate_restock_quantity()

    def export_summary_txt(self, filename="inventory_report.txt"):
        with open(filename, "w") as f:
            for p in self.products:
                f.write(f"{p.name}, Qty: {p.quantity}, Total: ${p.total_value():.2f}\n")

    def export_summary_csv(self, filename="inventory_summary.csv"):
        with open(filename, "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Name", "Quantity", "Total Value"])
            for p in self.products:
                writer.writerow([p.name, p.quantity, round(p.total_value(), 2)])
