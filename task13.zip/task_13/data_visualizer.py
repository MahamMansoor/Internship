import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Set plot style
sns.set(style="whitegrid")
os.makedirs("plots", exist_ok=True)

def load_and_clean_data(csv_path):
    try:
        df = pd.read_csv(csv_path)
        df.dropna(inplace=True)  # Remove rows with missing data
        return df
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return None

def plot_line_chart(df):
    plt.figure(figsize=(10, 6))
    sns.lineplot(x="Month", y="Revenue", data=df, marker="o")
    plt.title("Monthly Revenue Over Time")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("plots/Line_Chart.png")
    plt.close()

def plot_bar_chart(df):
    plt.figure(figsize=(10, 6))
    sns.barplot(x="Product", y="Sales", data=df, palette="viridis")
    plt.title("Sales per Product")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("plots/Bar_Chart.png")
    plt.close()

def plot_pie_chart(df):
    market_share = df.groupby("Region")["Sales"].sum()
    plt.figure(figsize=(8, 8))
    plt.pie(market_share, labels=market_share.index, autopct='%1.1f%%', startangle=140)
    plt.title("Market Share by Region")
    plt.tight_layout()
    plt.savefig("plots/Pie_Chart.png")
    plt.close()

def plot_heatmap(df):
    plt.figure(figsize=(10, 6))
    corr = df.select_dtypes(include='number').corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", linewidths=0.5)
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("plots/Heatmap.png")
    plt.close()

def generate_summary_report(df):
    report = []
    report.append("📊 Summary Report")
    report.append("------------------------")
    report.append(f"Total Records: {len(df)}")
    report.append(f"Total Revenue: ${df['Revenue'].sum():,.2f}")
    report.append(f"Top Product: {df.groupby('Product')['Sales'].sum().idxmax()}")
    report.append(f"Top Region by Sales: {df.groupby('Region')['Sales'].sum().idxmax()}")
    report.append("\nNumerical Data Overview:\n")
    report.append(str(df.describe()))
    with open("Summary_Report.txt", "w") as file:
        file.write("\n".join(report))

def main():
    print("📈 Data Visualizer: Starting Analysis...")
    csv_path = "sales.csv"  # Replace with your path if different
    df = load_and_clean_data(csv_path)
    if df is None:
        return

    # Plot and Save
    plot_line_chart(df)
    plot_bar_chart(df)
    plot_pie_chart(df)
    plot_heatmap(df)

    # Report
    generate_summary_report(df)
    print("✅ Visualizations saved in /plots")
    print("✅ Summary_Report.txt generated")

if __name__ == "__main__":
    main()
