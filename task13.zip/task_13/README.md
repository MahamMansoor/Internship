# 📈 Data Visualizer with Matplotlib & Seaborn

## Description
This project loads and cleans a CSV dataset, generates charts using `matplotlib` and `seaborn`, and creates a summary report.

## Charts Generated
- ✅ Line Chart (Monthly Revenue)
- ✅ Bar Chart (Sales per Product)
- ✅ Pie Chart (Market Share by Region)
- ✅ Heatmap (Feature Correlation)

## Output Files
- `/plots/*.png` → All charts
- `Summary_Report.txt` → Statistical overview

## How to Run
```bash
python data_visualizer.py
