# ✅ To-Do List Manager - CLI Tool

A simple command-line To-Do List utility built with Python and argparse.

## Features
- Add tasks
- View tasks
- Delete tasks
- Mark tasks as done
- Stores data in `todo_data.json`

## Usage

```bash
# Add a task
python cli_tool.py add "Buy groceries"

# View tasks
python cli_tool.py view

# Mark as done
python cli_tool.py done 1

# Delete a task
python cli_tool.py delete 2
