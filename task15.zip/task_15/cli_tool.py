import argparse
import json
import os

DATA_FILE = "todo_data.json"

def load_tasks():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as file:
        return json.load(file)

def save_tasks(tasks):
    with open(DATA_FILE, "w") as file:
        json.dump(tasks, file, indent=4)

def add_task(description):
    tasks = load_tasks()
    tasks.append({"task": description, "done": False})
    save_tasks(tasks)
    print(f"✅ Task added: {description}")

def view_tasks():
    tasks = load_tasks()
    if not tasks:
        print("📭 No tasks found.")
        return
    print("\n📋 To-Do List:")
    for i, task in enumerate(tasks, 1):
        status = "✅" if task["done"] else "❌"
        print(f"{i}. {task['task']} [{status}]")

def delete_task(index):
    tasks = load_tasks()
    if 0 <= index < len(tasks):
        removed = tasks.pop(index)
        save_tasks(tasks)
        print(f"🗑️ Deleted: {removed['task']}")
    else:
        print("❌ Invalid task number.")

def mark_done(index):
    tasks = load_tasks()
    if 0 <= index < len(tasks):
        tasks[index]["done"] = True
        save_tasks(tasks)
        print(f"☑️ Marked as done: {tasks[index]['task']}")
    else:
        print("❌ Invalid task number.")

def main():
    parser = argparse.ArgumentParser(description="📝 Simple To-Do List CLI Tool")
    subparsers = parser.add_subparsers(dest="command")

    # Add command
    parser_add = subparsers.add_parser("add", help="Add a new task")
    parser_add.add_argument("description", type=str, help="Task description")

    # View command
    subparsers.add_parser("view", help="View all tasks")

    # Delete command
    parser_delete = subparsers.add_parser("delete", help="Delete a task by number")
    parser_delete.add_argument("index", type=int, help="Task number to delete (starting from 1)")

    # Done command
    parser_done = subparsers.add_parser("done", help="Mark task as done")
    parser_done.add_argument("index", type=int, help="Task number to mark done (starting from 1)")

    args = parser.parse_args()

    if args.command == "add":
        add_task(args.description)
    elif args.command == "view":
        view_tasks()
    elif args.command == "delete":
        delete_task(args.index - 1)
    elif args.command == "done":
        mark_done(args.index - 1)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
