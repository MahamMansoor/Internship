Capstone Project Planning Document
📌 Project Title:
"Drone-Based Real-Time Target Recognition and Tracking System (DTRTS)"

🎯 Objective:
To develop a Python-based system that uses computer vision and deep learning to detect, track, and analyze moving targets (e.g., cars, people, structures) in aerial drone footage in real time, with visualization of movement paths and accuracy (CEP - Circular Error Probable).

This solution aims to support surveillance, search & rescue, and military reconnaissance by automating target monitoring from drone video feeds.

🌟 Key Features:
🎥 Upload aerial drone video (e.g., VisDrone, UAV footage)

🧠 Detect multiple object types (person, vehicle, etc.) using YOLOv8

🔁 Select one or more targets for tracking

🧭 Track with DeepSORT, visualize trajectory & speed

🎯 CEP (Circular Error Probable) visualization for positional accuracy

📊 Export:

CSV logs of tracking

Annotated output video

KML for Google Earth mapping

🖥️ Web UI using Gradio or Streamlit for interactive use

✅ Error handling for video processing, API failures, etc.

🧰 Technologies / Tools:
Purpose	Tools/Libraries
Object Detection	YOLOv8 (ultralytics)
Object Tracking	DeepSORT (deep-sort-realtime)
UI	Gradio or Streamlit
Visualization	OpenCV, Matplotlib
CEP Computation	NumPy, Geospatial math
Export Reports	Pandas, CSV, SimpleKML
Deployment	Google Colab / Streamlit Cloud
Optional	Firebase / MongoDB for logging

🗓️ Timeline:
Week	Milestone
1	Project Planning + Dataset Collection (e.g., VisDrone)
2	Implement YOLO Detection + Video Upload
3	Add DeepSORT Tracking + Target Selection UI
4	CEP Calculation + Trajectory Mapping (Matplotlib)
5	Export Logs, Annotated Video, and KML
6	UI Enhancements + Error Handling
7	Final Integration + GitHub + Demo Video
8	Final Pitch + LinkedIn Post

👥 Team Members & Roles :
Maham 	, YOLO+DeepSORT Implementation, UI/Export