import pandas as pd
import streamlit as st

st.title("📊 Automated Sales Report Generator")

uploaded_file = st.file_uploader("Upload your CSV file", type="csv")

if uploaded_file:
    try:
        df = pd.read_csv(uploaded_file)
        df.columns = df.columns.str.strip()
        df['Unit Price'] = pd.to_numeric(df['Unit Price'], errors='coerce')
        df['Units Sold'] = pd.to_numeric(df['Units Sold'], errors='coerce')
        df.dropna(inplace=True)

        df['Revenue'] = df['Units Sold'] * df['Unit Price']
        summary = df.groupby('Product')['Revenue'].sum().sort_values(ascending=False)

        st.subheader("📈 Product Revenue")
        for product, revenue in summary.items():
            st.write(f"**{product}** – Revenue: Rs. {int(revenue)}")

        st.success(f"🔸 Total Revenue: Rs. {int(df['Revenue'].sum())}")
        st.info(f"🔸 Top Product: {summary.idxmax()}")

    except Exception as e:
        st.error(f"Error: {e}")
