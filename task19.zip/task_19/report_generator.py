import pandas as pd

def generate_report(csv_path='sales.csv', report_path='report.txt'):
    try:
        # Read CSV
        df = pd.read_csv(csv_path)
        df.columns = df.columns.str.strip()  # Clean column names
        
        # Convert Unit Price to numeric (handle bad data)
        df['Unit Price'] = pd.to_numeric(df['Unit Price'], errors='coerce')
        df['Units Sold'] = pd.to_numeric(df['Units Sold'], errors='coerce')

        # Drop rows with missing values
        df.dropna(inplace=True)

        # Calculate Revenue
        df['Revenue'] = df['Units Sold'] * df['Unit Price']

        # Group by Product
        product_summary = df.groupby('Product')['Revenue'].sum().sort_values(ascending=False)

        # Prepare report lines
        lines = ["📊 Sales Summary"]
        for product, revenue in product_summary.items():
            lines.append(f"Product: {product} – Revenue: {int(revenue)}")

        total_revenue = int(df['Revenue'].sum())
        top_product = product_summary.idxmax()

        lines.append(f"\n🔸 Total Revenue: {total_revenue}")
        lines.append(f"🔸 Top Product: {top_product}")

        # Write to report.txt
        with open(report_path, 'w') as f:
            f.write('\n'.join(lines))

        print(f"[✅] Report generated and saved to {report_path}")

    except Exception as e:
        print(f"[❌] Error: {e}")

# Run the report generator
if __name__ == "__main__":
    generate_report()
